import sys
sys.path.insert(0,"/var/task")
from app.main import lambda_handler
