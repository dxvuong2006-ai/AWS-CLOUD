from sqlalchemy.orm import Session

from app.models.course import Course
from app.models.section import Section
from app.lesson_states import LessonStatus

# Tạo khóa học mới
def create_course(
    db: Session,
    course_data: dict,
) -> Course:
    course = Course(**course_data)

    db.add(course)
    db.commit()
    db.refresh(course)

    return course

# lấy danh sách theo id khóa học
def get_course_by_id(db: Session, course_id: int) -> Course | None:
    return db.query(Course).filter(Course.id == course_id).first()


def lock_by_id(db: Session, course_id: int) -> Course | None:
    return (
        db.query(Course).filter(Course.id == course_id).populate_existing()
        .with_for_update(nowait=True).first()
    )


def lock_sections(db: Session, course_id: int) -> list[Section]:
    return (
        db.query(Section).filter(Section.course_id == course_id).order_by(Section.id)
        .populate_existing().with_for_update(nowait=True).all()
    )


def mark_published(db: Session, course: Course, lessons) -> None:
    for lesson in lessons:
        lesson.status = LessonStatus.PUBLISHED.value
    course.status = "PUBLISHED"
    db.flush()


def get_courses_by_instructor(db: Session, instructor_id: int) -> list[Course]:
    return (
        db.query(Course)
        .filter(Course.instructor_id == instructor_id)
        .order_by(Course.updated_at.desc(), Course.id.desc())
        .all()
    )

# Lấy danh sách khóa học đã publish
def get_published_courses(db: Session) -> list[Course]:
    return (
        db.query(Course)
        .filter(Course.status == "PUBLISHED")
        .order_by(Course.id.desc())
        .all()
    )

# Lấy chi tiết khóa học đã publish
def get_published_course_by_id(
    db: Session,
    course_id: int,
) -> Course | None:
    return (
        db.query(Course)
        .filter(
            Course.id == course_id,
            Course.status == "PUBLISHED",
        )
        .first()
    )

# Lấy khóa học thuộc một giảng viên
def get_course_by_id_and_instructor(
    db: Session,
    course_id: int,
    instructor_id: int,
) -> Course | None:
    return (
        db.query(Course)
        .filter(
            Course.id == course_id,
            Course.instructor_id == instructor_id,
        )
        .first()
    )


# Cập nhật khóa học thuộc một giảng viên
def update_course(
    db: Session,
    course_id: int,
    instructor_id: int,
    update_data: dict,
) -> Course | None:
    course = get_course_by_id_and_instructor(
        db,
        course_id,
        instructor_id,
    )

    if course is None:
        return None

    for key, value in update_data.items():
        setattr(course, key, value)

    db.commit()
    db.refresh(course)

    return course
